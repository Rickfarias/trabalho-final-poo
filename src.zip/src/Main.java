import sistemapag.SistemaPag;
import varejo.Loja;

public class Main {
    public static void main(String[] args) {
        Loja loja = new Loja();loja.cadastroLoja();SistemaPag sp = new SistemaPag(loja);sp.sisPagMenu();sp.gerarRelatorio();
    }
}